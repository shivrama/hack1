from pyspark.sql.session import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark.sql import Column
import argparse
from datetime import *
import traceback
import sys

# data incorrect until output 14 product101 is populated although product is used eg : U100004
# CHECK user vintage 0 and active os for U100042
# trying to add list for active os


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--visitorlogpath')
    parser.add_argument('--userfilepath')
    parser.add_argument('--inputdate')
    parser.add_argument('--outputpath')
    print("*** STARTED ***")
    spark = SparkSession.builder.appName("datahack1").getOrCreate()
    args = parser.parse_args()
    # initialization and assignment of parameters
    visitorlogpath = args.visitorlogpath
    userfilepath = args.userfilepath
    inputdate = args.inputdate
    outputpath = args.outputpath
    #28 - May - 2018

    inputdate1 = datetime.strptime(inputdate, '%d-%b-%Y')
    startdate = inputdate1 - timedelta(days=21)
    days_15 = inputdate1 - timedelta(days=15)
    days_7 = inputdate1 - timedelta(days=7)
    print(inputdate1, startdate, days_15, inputdate1, days_7)
    try:
        # regex and data conversion for normalization of date and other columns
        regex1 = "^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})\.(\d{3})$"
        regex2 = "^(\d{19})$"
        convert1 = to_timestamp(col("VisitDateTime"), "yyyy-MM-dd HH:mm:ss.SSS")
        convert2 = from_unixtime(substring(col("VisitDateTime"), 1, 10))
        convert3 = to_date(substring(col("Signup Date"), 1, 10), "yyyy-MM-dd")

        cond1 = when(col("VisitDateTime").rlike(regex1), convert1).when(col("VisitDateTime").rlike(regex2), convert2)\
            .otherwise(None)
        visitor1 = spark.read.option("inferSchema", True).option("header", True).csv(visitorlogpath)\
            .na.fill('1970-01-01 00:00:00.000', ['VisitDateTime'])\
            .withColumn("VisitDateTime1", cond1).withColumn("VisitDateTime2", to_timestamp(col("VisitDateTime1")))\
            .drop("VisitDateTime1").withColumnRenamed("VisitDateTime2", "VisitDateTime1").filter(col("UserID").isNotNull())\
            .withColumn('ProductID2', upper(col('ProductID'))).withColumn('Activity2', upper(col('Activity')))\
            .withColumn('UserID2', upper(col('UserID'))).withColumn('OS2', upper(col('OS')))\
            .drop('ProductID', 'Activity', 'UserID', 'OS').withColumnRenamed('ProductID2', 'ProductID')\
            .withColumnRenamed('Activity2', 'Activity').withColumnRenamed('UserID2', 'UserID').withColumnRenamed('OS2', 'OS')


        user1 = spark.read.option("inferSchema", True).option("header", True).csv(userfilepath).withColumn("Signup1", convert3)\
            .withColumn("User_Vintage", datediff(lit(inputdate1), col("Signup1")))
        w1 = Window.partitionBy("UserID")#.orderBy("VisitDate")
        w4 = Window.partitionBy("UserID", "ProductID1")
        w5 = Window.partitionBy("UserID", "ProductID")
        df3 = visitor1.withColumn("VisitDate", to_date("VisitDateTime1")).filter(col("VisitDateTime1").between(startdate, inputdate1))\
            .withColumn("VisitDate1", when(col("VisitDateTime1").between(days_7, inputdate1), col("VisitDate")).otherwise(None))\
            .withColumn("ProductID1", when(col("VisitDateTime1").between(days_15, inputdate1), col("ProductID")).otherwise(None)).cache()
        # generation of values for No_of_days_Visited_7_Days , No_Of_Products_Viewed_15_Days
        df4 = df3.withColumn("No_of_days_Visited_7_Days", size(collect_set("VisitDate1").over(w1))) \
            .withColumn("No_Of_Products_Viewed_15_Days", size(collect_set("ProductID1").over(w1)))\
            .dropDuplicates(['UserID']).cache()

        # generation of value for Most_Viewed_product_15_Days
        most_viewed1 = df3.filter(upper(col('Activity')) == 'PAGELOAD').filter(col('ProductID1').isNotNull())\
            .groupBy('UserID', 'ProductID1')\
            .agg(count('ProductID1').alias('Most_Viewed'), max('VisitDateTime1').alias('recent1'))


        most_viewed2 = most_viewed1.withColumn('maxcount', max('Most_Viewed').over(w1))\
            .withColumn('recent2', max('recent1').over(w4)) \
            .filter(col('Most_Viewed') == col('maxcount')).filter(col('recent1') == col('recent2'))\
            .withColumn('Most_Viewed_product_15_Days', when(col('Most_Viewed') == 0, 'Product101').otherwise(col('ProductID1')))\
            .drop('maxcount', 'recent1', 'recent2')

        # generation of value for Most_Active_OS
        active_os = visitor1.groupBy('UserID', 'OS').agg(count('OS').alias('active_os'))
        active_os2 = active_os.withColumn('maxcount', max('active_os').over(w1)) \
            .filter(col('active_os') == col('maxcount')).withColumnRenamed('OS', 'Most_Active_OS') \
            .drop('maxcount')
        # generation of value for Most_Active_OS
        most_recent1 = df3.filter(upper(col('Activity')) == 'PAGELOAD').filter(col('ProductID').isNotNull())\
            .withColumn('recenttime1', max('VisitDateTime1').over(w1)) \
            .filter(" VisitDateTime1 == recenttime1").withColumn('Recently_Viewed_Product', when(col('ProductID').isNull(), 'Product101').otherwise(col('ProductID')))\
            .select('UserID', 'Recently_Viewed_Product').dropDuplicates(['UserID'])
        # generation of value for Pageloads_last_7_days
        pagesload1 = df3.filter(upper(col('Activity')) == 'PAGELOAD').filter(col("VisitDateTime1").between(days_7, inputdate1))\
            .withColumn('Pageloads_last_7_days', count('Activity').over(w1)) \
            .select('UserID', 'Pageloads_last_7_days').dropDuplicates(['UserID'])
        # generation of value for Clicks_last_7_days
        clicks1 = df3.filter(upper(col('Activity')) == 'CLICK').filter(col("VisitDateTime1").between(days_7, inputdate1)) \
            .withColumn('Clicks_last_7_days', count('Activity').over(w1)) \
            .select('UserID', 'Clicks_last_7_days').dropDuplicates(['UserID'])
        # joining of all individuals features
        finaldf = user1.join(df4, ["UserID"], how="left").join(most_viewed2, ["UserID"], how="left").join(active_os2, ["UserID"], how="left") \
            .join(most_recent1, ["UserID"], how="left").join(pagesload1, ["UserID"], how="left").join(clicks1, ["UserID"], how="left") \
            .na.fill('Product101', ['Recently_Viewed_Product', 'Most_Viewed_product_15_Days']) \
            .na.fill(0, ['No_of_days_Visited_7_Days', 'No_Of_Products_Viewed_15_Days', 'User_Vintage', 'Clicks_last_7_days', 'Pageloads_last_7_days']) \
            .select('UserID', 'No_of_days_Visited_7_Days', 'No_Of_Products_Viewed_15_Days', 'User_Vintage', 'Most_Viewed_product_15_Days', 'Most_Active_OS', 'Recently_Viewed_Product', 'Pageloads_last_7_days', 'Clicks_last_7_days') \
            .dropDuplicates(['UserID']).orderBy('UserID').cache()
        finaldf.coalesce(1).write.option('header', True).csv(outputpath)
        print("*** completed ***")

    except Exception:
        print(traceback.format_exc())
        sys.exit(1)
    finally:
        spark.catalog.clearCache()

